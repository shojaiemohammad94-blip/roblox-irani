const express = require("express");
const path = require("path");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] },
  transports: ["websocket", "polling"]
});
const PORT = process.env.PORT || 3000;
const rooms = new Map();

app.use(express.static(__dirname));
app.get("/health", (_req, res) => res.json({
  ok: true,
  name: "Roblox Irani multiplayer server",
  rooms: rooms.size
}));

function roomPlayers(room) {
  const ids = io.sockets.adapter.rooms.get(room);
  const out = {};
  if (!ids) return out;
  for (const id of ids) {
    const s = io.sockets.sockets.get(id);
    if (s && s.data.player) out[id] = s.data.player;
  }
  return out;
}

io.on("connection", socket => {
  socket.on("joinRoom", ({ name, room, skin } = {}) => {
    const safeRoom = String(room || "IRAN1").toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 16) || "IRAN1";
    const safeName = String(name || "بازیکن").replace(/[<>]/g, "").slice(0, 18) || "بازیکن";
    if (socket.data.room) socket.leave(socket.data.room);
    socket.data.room = safeRoom;
    socket.data.player = { name: safeName, skin: String(skin || "#54e6d4"), pos: { x: 0.5, y: 0.75 }, mode: "parkour" };
    socket.join(safeRoom);
    socket.to(safeRoom).emit("playerJoined", { name: safeName });
    io.to(safeRoom).emit("players", roomPlayers(safeRoom));
  });

  socket.on("move", pos => {
    const room = socket.data.room;
    const player = socket.data.player;
    if (!room || !player || !pos || typeof pos.x !== "number" || typeof pos.y !== "number") return;
    player.pos = { x: Math.max(0, Math.min(1, pos.x)), y: Math.max(0, Math.min(1, pos.y)) };
    player.mode = String(pos.mode || "parkour").slice(0, 16);
    player.skin = String(pos.skin || player.skin).slice(0, 24);
    socket.to(room).emit("players", roomPlayers(room));
  });

  socket.on("disconnect", () => {
    const room = socket.data.room;
    if (room) {
      socket.to(room).emit("playerLeft", socket.id);
      io.to(room).emit("players", roomPlayers(room));
    }
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Roblox Irani server listening on port ${PORT}`);
});
